﻿// See https://aka.ms/new-console-template for more information
using Asinkronus_Multithread;

//await Asinkronus.ExecuteAsyncFunctions();
Multithreading.ExecuteMultithreading();